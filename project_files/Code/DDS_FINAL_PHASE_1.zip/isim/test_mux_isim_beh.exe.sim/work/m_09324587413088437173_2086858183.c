/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/ishaan/UPLOAD/TESTING/DDS_FINAL_PHASE_1/test_mux.v";
static const char *ng1 = "Error is in the wire - %d";
static const char *ng2 = "The wire is stuck at %b";
static int ng3[] = {1, 0};
static int ng4[] = {0, 0};
static int ng5[] = {9, 0};
static int ng6[] = {2, 0};
static int ng7[] = {3, 0};
static int ng8[] = {4, 0};
static int ng9[] = {5, 0};
static int ng10[] = {6, 0};
static int ng11[] = {7, 0};
static int ng12[] = {8, 0};
static const char *ng13 = "No errors in the module.";



static int sp_test_current_config(char *t1, char *t2)
{
    char t9[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t10;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;
    char *t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    char *t31;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    char *t39;
    char *t40;
    char *t41;
    char *t42;
    char *t43;
    char *t44;
    char *t45;
    char *t46;
    int t47;
    char *t48;
    char *t49;
    char *t50;
    char *t51;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 848);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(23, ng0);

LAB5:    xsi_set_current_line(24, ng0);
    t5 = (t1 + 2776U);
    t6 = *((char **)t5);
    t5 = (t1 + 3656);
    t7 = (t5 + 56U);
    t8 = *((char **)t7);
    memset(t9, 0, 8);
    t10 = (t6 + 4);
    t11 = (t8 + 4);
    t12 = *((unsigned int *)t6);
    t13 = *((unsigned int *)t8);
    t14 = (t12 ^ t13);
    t15 = *((unsigned int *)t10);
    t16 = *((unsigned int *)t11);
    t17 = (t15 ^ t16);
    t18 = (t14 | t17);
    t19 = *((unsigned int *)t10);
    t20 = *((unsigned int *)t11);
    t21 = (t19 | t20);
    t22 = (~(t21));
    t23 = (t18 & t22);
    if (t23 != 0)
        goto LAB7;

LAB6:    if (t21 != 0)
        goto LAB8;

LAB9:    t25 = (t9 + 4);
    t26 = *((unsigned int *)t25);
    t27 = (~(t26));
    t28 = *((unsigned int *)t9);
    t29 = (t28 & t27);
    t30 = (t29 != 0);
    if (t30 > 0)
        goto LAB10;

LAB11:
LAB12:
LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;

LAB1:    return t0;
LAB7:    *((unsigned int *)t9) = 1;
    goto LAB9;

LAB8:    t24 = (t9 + 4);
    *((unsigned int *)t9) = 1;
    *((unsigned int *)t24) = 1;
    goto LAB9;

LAB10:    xsi_set_current_line(24, ng0);

LAB13:    xsi_set_current_line(25, ng0);
    t31 = (t2 + 56U);
    t32 = *((char **)t31);
    t33 = (t2 + 56U);
    t34 = *((char **)t33);
    xsi_vlog_subprograminvocation_setJumpstate(t2, t34, &&LAB14);
    t35 = (t2 + 56U);
    t36 = *((char **)t35);
    t37 = (t1 + 1712);
    t38 = xsi_create_subprogram_invocation(t36, 0, t1, t37, 0, t2);
    xsi_vlog_subprogram_pushinvocation(t37, t38);

LAB16:    t39 = (t2 + 64U);
    t40 = *((char **)t39);
    t41 = (t40 + 80U);
    t42 = *((char **)t41);
    t43 = (t42 + 272U);
    t44 = *((char **)t43);
    t45 = (t44 + 0U);
    t46 = *((char **)t45);
    t47 = ((int  (*)(char *, char *))t46)(t1, t40);
    if (t47 == -1)
        goto LAB17;

LAB18:    if (t47 != 0)
        goto LAB19;

LAB14:    t40 = (t1 + 1712);
    xsi_vlog_subprogram_popinvocation(t40);

LAB15:    t48 = (t2 + 64U);
    t49 = *((char **)t48);
    t48 = (t1 + 1712);
    t50 = (t2 + 56U);
    t51 = *((char **)t50);
    xsi_delete_subprogram_invocation(t48, t49, t1, t51, t2);
    goto LAB12;

LAB17:    t0 = -1;
    goto LAB1;

LAB19:    t39 = (t2 + 48U);
    *((char **)t39) = &&LAB16;
    goto LAB1;

}

static int sp_display_task(char *t1, char *t2)
{
    char t9[8];
    char t10[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    char *t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    char *t32;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 1280);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(31, ng0);

LAB5:    xsi_set_current_line(32, ng0);
    t5 = (t1 + 3816);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t1 + 1280);
    xsi_vlogfile_write(1, 0, 0, ng1, 2, t8, (char)119, t7, 32);
    xsi_set_current_line(33, ng0);
    t4 = (t1 + 3656);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t1 + 3656);
    t8 = (t7 + 72U);
    t11 = *((char **)t8);
    t12 = (t1 + 3816);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    xsi_vlog_generic_get_index_select_value(t10, 1, t6, t11, 2, t14, 32, 1);
    memset(t9, 0, 8);
    t15 = (t10 + 4);
    t16 = *((unsigned int *)t15);
    t17 = (~(t16));
    t18 = *((unsigned int *)t10);
    t19 = (t18 & t17);
    t20 = (t19 & 1U);
    if (t20 != 0)
        goto LAB9;

LAB7:    if (*((unsigned int *)t15) == 0)
        goto LAB6;

LAB8:    t21 = (t9 + 4);
    *((unsigned int *)t9) = 1;
    *((unsigned int *)t21) = 1;

LAB9:    t22 = (t9 + 4);
    t23 = (t10 + 4);
    t24 = *((unsigned int *)t10);
    t25 = (~(t24));
    *((unsigned int *)t9) = t25;
    *((unsigned int *)t22) = 0;
    if (*((unsigned int *)t23) != 0)
        goto LAB11;

LAB10:    t30 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t30 & 1U);
    t31 = *((unsigned int *)t22);
    *((unsigned int *)t22) = (t31 & 1U);
    t32 = (t1 + 1280);
    xsi_vlogfile_write(1, 0, 0, ng2, 2, t32, (char)118, t9, 1);
    xsi_set_current_line(34, ng0);
    xsi_vlog_finish(1);

LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;

LAB1:    return t0;
LAB6:    *((unsigned int *)t9) = 1;
    goto LAB9;

LAB11:    t26 = *((unsigned int *)t9);
    t27 = *((unsigned int *)t23);
    *((unsigned int *)t9) = (t26 | t27);
    t28 = *((unsigned int *)t22);
    t29 = *((unsigned int *)t23);
    *((unsigned int *)t22) = (t28 | t29);
    goto LAB10;

}

static int sp_update_task(char *t1, char *t2)
{
    char t5[8];
    char t17[8];
    char t26[8];
    char t33[8];
    int t0;
    char *t3;
    char *t4;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    char *t15;
    char *t16;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    char *t34;
    char *t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    char *t48;
    char *t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;
    int t59;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 1712);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(39, ng0);

LAB5:    xsi_set_current_line(40, ng0);
    t6 = ((char*)((ng3)));
    memset(t5, 0, 8);
    xsi_vlog_signed_unary_minus(t5, 32, t6, 32);
    t7 = (t1 + 3816);
    xsi_vlogvar_assign_value(t7, t5, 0, 0, 32);
    xsi_set_current_line(41, ng0);
    xsi_set_current_line(41, ng0);
    t4 = ((char*)((ng4)));
    t6 = (t1 + 3976);
    xsi_vlogvar_assign_value(t6, t4, 0, 0, 32);

LAB6:    t4 = (t1 + 3976);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t8 = ((char*)((ng5)));
    memset(t5, 0, 8);
    xsi_vlog_signed_less(t5, 32, t7, 32, t8, 32);
    t9 = (t5 + 4);
    t10 = *((unsigned int *)t9);
    t11 = (~(t10));
    t12 = *((unsigned int *)t5);
    t13 = (t12 & t11);
    t14 = (t13 != 0);
    if (t14 > 0)
        goto LAB7;

LAB8:
LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;

LAB1:    return t0;
LAB7:    xsi_set_current_line(41, ng0);

LAB9:    xsi_set_current_line(42, ng0);
    t15 = (t1 + 2776U);
    t16 = *((char **)t15);
    t15 = (t1 + 2736U);
    t18 = (t15 + 72U);
    t19 = *((char **)t18);
    t20 = (t1 + 3976);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    xsi_vlog_generic_get_index_select_value(t17, 1, t16, t19, 2, t22, 32, 1);
    t23 = (t1 + 3656);
    t24 = (t23 + 56U);
    t25 = *((char **)t24);
    t27 = (t1 + 3656);
    t28 = (t27 + 72U);
    t29 = *((char **)t28);
    t30 = (t1 + 3976);
    t31 = (t30 + 56U);
    t32 = *((char **)t31);
    xsi_vlog_generic_get_index_select_value(t26, 1, t25, t29, 2, t32, 32, 1);
    memset(t33, 0, 8);
    t34 = (t17 + 4);
    t35 = (t26 + 4);
    t36 = *((unsigned int *)t17);
    t37 = *((unsigned int *)t26);
    t38 = (t36 ^ t37);
    t39 = *((unsigned int *)t34);
    t40 = *((unsigned int *)t35);
    t41 = (t39 ^ t40);
    t42 = (t38 | t41);
    t43 = *((unsigned int *)t34);
    t44 = *((unsigned int *)t35);
    t45 = (t43 | t44);
    t46 = (~(t45));
    t47 = (t42 & t46);
    if (t47 != 0)
        goto LAB11;

LAB10:    if (t45 != 0)
        goto LAB12;

LAB13:    t49 = (t33 + 4);
    t50 = *((unsigned int *)t49);
    t51 = (~(t50));
    t52 = *((unsigned int *)t33);
    t53 = (t52 & t51);
    t54 = (t53 != 0);
    if (t54 > 0)
        goto LAB14;

LAB15:
LAB16:    xsi_set_current_line(41, ng0);
    t4 = (t1 + 3976);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t8 = ((char*)((ng3)));
    memset(t5, 0, 8);
    xsi_vlog_signed_add(t5, 32, t7, 32, t8, 32);
    t9 = (t1 + 3976);
    xsi_vlogvar_assign_value(t9, t5, 0, 0, 32);
    goto LAB6;

LAB11:    *((unsigned int *)t33) = 1;
    goto LAB13;

LAB12:    t48 = (t33 + 4);
    *((unsigned int *)t33) = 1;
    *((unsigned int *)t48) = 1;
    goto LAB13;

LAB14:    xsi_set_current_line(42, ng0);

LAB17:    xsi_set_current_line(43, ng0);
    t55 = (t1 + 3976);
    t56 = (t55 + 56U);
    t57 = *((char **)t56);
    t58 = (t1 + 3816);
    xsi_vlogvar_assign_value(t58, t57, 0, 0, 32);
    xsi_set_current_line(44, ng0);
    t4 = (t2 + 56U);
    t6 = *((char **)t4);
    t7 = (t2 + 56U);
    t8 = *((char **)t7);
    xsi_vlog_subprograminvocation_setJumpstate(t2, t8, &&LAB18);
    t9 = (t2 + 56U);
    t15 = *((char **)t9);
    t16 = (t1 + 1280);
    t18 = xsi_create_subprogram_invocation(t15, 0, t1, t16, 0, t2);
    xsi_vlog_subprogram_pushinvocation(t16, t18);

LAB20:    t19 = (t2 + 64U);
    t20 = *((char **)t19);
    t21 = (t20 + 80U);
    t22 = *((char **)t21);
    t23 = (t22 + 272U);
    t24 = *((char **)t23);
    t25 = (t24 + 0U);
    t27 = *((char **)t25);
    t59 = ((int  (*)(char *, char *))t27)(t1, t20);
    if (t59 == -1)
        goto LAB21;

LAB22:    if (t59 != 0)
        goto LAB23;

LAB18:    t20 = (t1 + 1280);
    xsi_vlog_subprogram_popinvocation(t20);

LAB19:    t28 = (t2 + 64U);
    t29 = *((char **)t28);
    t28 = (t1 + 1280);
    t30 = (t2 + 56U);
    t31 = *((char **)t30);
    xsi_delete_subprogram_invocation(t28, t29, t1, t31, t2);
    xsi_set_current_line(45, ng0);
    xsi_vlog_finish(1);
    goto LAB16;

LAB21:    t0 = -1;
    goto LAB1;

LAB23:    t19 = (t2 + 48U);
    *((char **)t19) = &&LAB20;
    goto LAB1;

}

static int sp_update_golden(char *t1, char *t2)
{
    char t9[8];
    char t29[8];
    char t63[8];
    char t98[8];
    char t127[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    unsigned int t15;
    int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    char *t30;
    char *t31;
    char *t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    int t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;
    unsigned int t49;
    int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    unsigned int t61;
    unsigned int t62;
    char *t64;
    char *t65;
    char *t66;
    char *t67;
    unsigned int t68;
    unsigned int t69;
    unsigned int t70;
    char *t71;
    char *t72;
    char *t73;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    unsigned int t79;
    unsigned int t80;
    char *t81;
    char *t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    unsigned int t86;
    unsigned int t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    int t91;
    unsigned int t92;
    unsigned int t93;
    unsigned int t94;
    unsigned int t95;
    unsigned int t96;
    unsigned int t97;
    unsigned int t99;
    unsigned int t100;
    unsigned int t101;
    char *t102;
    char *t103;
    char *t104;
    unsigned int t105;
    unsigned int t106;
    unsigned int t107;
    unsigned int t108;
    unsigned int t109;
    unsigned int t110;
    unsigned int t111;
    char *t112;
    char *t113;
    unsigned int t114;
    unsigned int t115;
    unsigned int t116;
    int t117;
    unsigned int t118;
    unsigned int t119;
    unsigned int t120;
    int t121;
    unsigned int t122;
    unsigned int t123;
    unsigned int t124;
    unsigned int t125;
    char *t126;
    char *t128;
    char *t129;
    char *t130;
    char *t131;
    char *t132;
    unsigned int t133;
    int t134;

LAB0:    t0 = 1;
    t3 = (t2 + 48U);
    t4 = *((char **)t3);
    if (t4 == 0)
        goto LAB2;

LAB3:    goto *t4;

LAB2:    t4 = (t1 + 2144);
    xsi_vlog_subprogram_setdisablestate(t4, &&LAB4);
    xsi_set_current_line(52, ng0);

LAB5:    xsi_set_current_line(53, ng0);
    t5 = (t1 + 3336);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t1 + 3656);
    t10 = (t1 + 3656);
    t11 = (t10 + 72U);
    t12 = *((char **)t11);
    t13 = ((char*)((ng4)));
    xsi_vlog_generic_convert_bit_index(t9, t12, 2, t13, 32, 1);
    t14 = (t9 + 4);
    t15 = *((unsigned int *)t14);
    t16 = (!(t15));
    if (t16 == 1)
        goto LAB6;

LAB7:    xsi_set_current_line(54, ng0);
    t4 = (t1 + 3496);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t1 + 3656);
    t8 = (t1 + 3656);
    t10 = (t8 + 72U);
    t11 = *((char **)t10);
    t12 = ((char*)((ng3)));
    xsi_vlog_generic_convert_bit_index(t9, t11, 2, t12, 32, 1);
    t13 = (t9 + 4);
    t15 = *((unsigned int *)t13);
    t16 = (!(t15));
    if (t16 == 1)
        goto LAB8;

LAB9:    xsi_set_current_line(55, ng0);
    t4 = (t1 + 3176);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t1 + 3656);
    t8 = (t1 + 3656);
    t10 = (t8 + 72U);
    t11 = *((char **)t10);
    t12 = ((char*)((ng6)));
    xsi_vlog_generic_convert_bit_index(t9, t11, 2, t12, 32, 1);
    t13 = (t9 + 4);
    t15 = *((unsigned int *)t13);
    t16 = (!(t15));
    if (t16 == 1)
        goto LAB10;

LAB11:    xsi_set_current_line(56, ng0);
    t4 = (t1 + 3176);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t1 + 3656);
    t8 = (t1 + 3656);
    t10 = (t8 + 72U);
    t11 = *((char **)t10);
    t12 = ((char*)((ng7)));
    xsi_vlog_generic_convert_bit_index(t9, t11, 2, t12, 32, 1);
    t13 = (t9 + 4);
    t15 = *((unsigned int *)t13);
    t16 = (!(t15));
    if (t16 == 1)
        goto LAB12;

LAB13:    xsi_set_current_line(57, ng0);
    t4 = (t1 + 3176);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t1 + 3656);
    t8 = (t1 + 3656);
    t10 = (t8 + 72U);
    t11 = *((char **)t10);
    t12 = ((char*)((ng8)));
    xsi_vlog_generic_convert_bit_index(t9, t11, 2, t12, 32, 1);
    t13 = (t9 + 4);
    t15 = *((unsigned int *)t13);
    t16 = (!(t15));
    if (t16 == 1)
        goto LAB14;

LAB15:    xsi_set_current_line(58, ng0);
    t4 = (t1 + 3176);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memset(t9, 0, 8);
    t7 = (t6 + 4);
    t15 = *((unsigned int *)t7);
    t17 = (~(t15));
    t18 = *((unsigned int *)t6);
    t19 = (t18 & t17);
    t20 = (t19 & 1U);
    if (t20 != 0)
        goto LAB19;

LAB17:    if (*((unsigned int *)t7) == 0)
        goto LAB16;

LAB18:    t8 = (t9 + 4);
    *((unsigned int *)t9) = 1;
    *((unsigned int *)t8) = 1;

LAB19:    t10 = (t9 + 4);
    t11 = (t6 + 4);
    t21 = *((unsigned int *)t6);
    t22 = (~(t21));
    *((unsigned int *)t9) = t22;
    *((unsigned int *)t10) = 0;
    if (*((unsigned int *)t11) != 0)
        goto LAB21;

LAB20:    t27 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t27 & 1U);
    t28 = *((unsigned int *)t10);
    *((unsigned int *)t10) = (t28 & 1U);
    t12 = (t1 + 3656);
    t13 = (t1 + 3656);
    t14 = (t13 + 72U);
    t30 = *((char **)t14);
    t31 = ((char*)((ng9)));
    xsi_vlog_generic_convert_bit_index(t29, t30, 2, t31, 32, 1);
    t32 = (t29 + 4);
    t33 = *((unsigned int *)t32);
    t16 = (!(t33));
    if (t16 == 1)
        goto LAB22;

LAB23:    xsi_set_current_line(59, ng0);
    t4 = (t1 + 3496);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t1 + 3176);
    t8 = (t7 + 56U);
    t10 = *((char **)t8);
    t15 = *((unsigned int *)t6);
    t17 = *((unsigned int *)t10);
    t18 = (t15 & t17);
    *((unsigned int *)t9) = t18;
    t11 = (t6 + 4);
    t12 = (t10 + 4);
    t13 = (t9 + 4);
    t19 = *((unsigned int *)t11);
    t20 = *((unsigned int *)t12);
    t21 = (t19 | t20);
    *((unsigned int *)t13) = t21;
    t22 = *((unsigned int *)t13);
    t23 = (t22 != 0);
    if (t23 == 1)
        goto LAB24;

LAB25:
LAB26:    t31 = (t1 + 3656);
    t32 = (t1 + 3656);
    t45 = (t32 + 72U);
    t46 = *((char **)t45);
    t47 = ((char*)((ng10)));
    xsi_vlog_generic_convert_bit_index(t29, t46, 2, t47, 32, 1);
    t48 = (t29 + 4);
    t49 = *((unsigned int *)t48);
    t50 = (!(t49));
    if (t50 == 1)
        goto LAB27;

LAB28:    xsi_set_current_line(60, ng0);
    t4 = (t1 + 3336);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t1 + 3176);
    t8 = (t7 + 56U);
    t10 = *((char **)t8);
    memset(t9, 0, 8);
    t11 = (t10 + 4);
    t15 = *((unsigned int *)t11);
    t17 = (~(t15));
    t18 = *((unsigned int *)t10);
    t19 = (t18 & t17);
    t20 = (t19 & 1U);
    if (t20 != 0)
        goto LAB32;

LAB30:    if (*((unsigned int *)t11) == 0)
        goto LAB29;

LAB31:    t12 = (t9 + 4);
    *((unsigned int *)t9) = 1;
    *((unsigned int *)t12) = 1;

LAB32:    t13 = (t9 + 4);
    t14 = (t10 + 4);
    t21 = *((unsigned int *)t10);
    t22 = (~(t21));
    *((unsigned int *)t9) = t22;
    *((unsigned int *)t13) = 0;
    if (*((unsigned int *)t14) != 0)
        goto LAB34;

LAB33:    t27 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t27 & 1U);
    t28 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t28 & 1U);
    t33 = *((unsigned int *)t6);
    t34 = *((unsigned int *)t9);
    t35 = (t33 & t34);
    *((unsigned int *)t29) = t35;
    t30 = (t6 + 4);
    t31 = (t9 + 4);
    t32 = (t29 + 4);
    t36 = *((unsigned int *)t30);
    t37 = *((unsigned int *)t31);
    t39 = (t36 | t37);
    *((unsigned int *)t32) = t39;
    t40 = *((unsigned int *)t32);
    t41 = (t40 != 0);
    if (t41 == 1)
        goto LAB35;

LAB36:
LAB37:    t47 = (t1 + 3656);
    t48 = (t1 + 3656);
    t64 = (t48 + 72U);
    t65 = *((char **)t64);
    t66 = ((char*)((ng11)));
    xsi_vlog_generic_convert_bit_index(t63, t65, 2, t66, 32, 1);
    t67 = (t63 + 4);
    t68 = *((unsigned int *)t67);
    t50 = (!(t68));
    if (t50 == 1)
        goto LAB38;

LAB39:    xsi_set_current_line(61, ng0);
    t4 = (t1 + 3496);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = (t1 + 3176);
    t8 = (t7 + 56U);
    t10 = *((char **)t8);
    t15 = *((unsigned int *)t6);
    t17 = *((unsigned int *)t10);
    t18 = (t15 & t17);
    *((unsigned int *)t9) = t18;
    t11 = (t6 + 4);
    t12 = (t10 + 4);
    t13 = (t9 + 4);
    t19 = *((unsigned int *)t11);
    t20 = *((unsigned int *)t12);
    t21 = (t19 | t20);
    *((unsigned int *)t13) = t21;
    t22 = *((unsigned int *)t13);
    t23 = (t22 != 0);
    if (t23 == 1)
        goto LAB40;

LAB41:
LAB42:    t31 = (t1 + 3336);
    t32 = (t31 + 56U);
    t45 = *((char **)t32);
    t46 = (t1 + 3176);
    t47 = (t46 + 56U);
    t48 = *((char **)t47);
    memset(t29, 0, 8);
    t64 = (t48 + 4);
    t49 = *((unsigned int *)t64);
    t51 = (~(t49));
    t52 = *((unsigned int *)t48);
    t53 = (t52 & t51);
    t54 = (t53 & 1U);
    if (t54 != 0)
        goto LAB46;

LAB44:    if (*((unsigned int *)t64) == 0)
        goto LAB43;

LAB45:    t65 = (t29 + 4);
    *((unsigned int *)t29) = 1;
    *((unsigned int *)t65) = 1;

LAB46:    t66 = (t29 + 4);
    t67 = (t48 + 4);
    t55 = *((unsigned int *)t48);
    t56 = (~(t55));
    *((unsigned int *)t29) = t56;
    *((unsigned int *)t66) = 0;
    if (*((unsigned int *)t67) != 0)
        goto LAB48;

LAB47:    t61 = *((unsigned int *)t29);
    *((unsigned int *)t29) = (t61 & 1U);
    t62 = *((unsigned int *)t66);
    *((unsigned int *)t66) = (t62 & 1U);
    t68 = *((unsigned int *)t45);
    t69 = *((unsigned int *)t29);
    t70 = (t68 & t69);
    *((unsigned int *)t63) = t70;
    t71 = (t45 + 4);
    t72 = (t29 + 4);
    t73 = (t63 + 4);
    t74 = *((unsigned int *)t71);
    t75 = *((unsigned int *)t72);
    t76 = (t74 | t75);
    *((unsigned int *)t73) = t76;
    t77 = *((unsigned int *)t73);
    t78 = (t77 != 0);
    if (t78 == 1)
        goto LAB49;

LAB50:
LAB51:    t99 = *((unsigned int *)t9);
    t100 = *((unsigned int *)t63);
    t101 = (t99 | t100);
    *((unsigned int *)t98) = t101;
    t102 = (t9 + 4);
    t103 = (t63 + 4);
    t104 = (t98 + 4);
    t105 = *((unsigned int *)t102);
    t106 = *((unsigned int *)t103);
    t107 = (t105 | t106);
    *((unsigned int *)t104) = t107;
    t108 = *((unsigned int *)t104);
    t109 = (t108 != 0);
    if (t109 == 1)
        goto LAB52;

LAB53:
LAB54:    t126 = (t1 + 3656);
    t128 = (t1 + 3656);
    t129 = (t128 + 72U);
    t130 = *((char **)t129);
    t131 = ((char*)((ng12)));
    xsi_vlog_generic_convert_bit_index(t127, t130, 2, t131, 32, 1);
    t132 = (t127 + 4);
    t133 = *((unsigned int *)t132);
    t134 = (!(t133));
    if (t134 == 1)
        goto LAB55;

LAB56:
LAB4:    xsi_vlog_dispose_subprogram_invocation(t2);
    t4 = (t2 + 48U);
    *((char **)t4) = &&LAB2;
    t0 = 0;

LAB1:    return t0;
LAB6:    xsi_vlogvar_assign_value(t8, t7, 0, *((unsigned int *)t9), 1);
    goto LAB7;

LAB8:    xsi_vlogvar_assign_value(t7, t6, 0, *((unsigned int *)t9), 1);
    goto LAB9;

LAB10:    xsi_vlogvar_assign_value(t7, t6, 0, *((unsigned int *)t9), 1);
    goto LAB11;

LAB12:    xsi_vlogvar_assign_value(t7, t6, 0, *((unsigned int *)t9), 1);
    goto LAB13;

LAB14:    xsi_vlogvar_assign_value(t7, t6, 0, *((unsigned int *)t9), 1);
    goto LAB15;

LAB16:    *((unsigned int *)t9) = 1;
    goto LAB19;

LAB21:    t23 = *((unsigned int *)t9);
    t24 = *((unsigned int *)t11);
    *((unsigned int *)t9) = (t23 | t24);
    t25 = *((unsigned int *)t10);
    t26 = *((unsigned int *)t11);
    *((unsigned int *)t10) = (t25 | t26);
    goto LAB20;

LAB22:    xsi_vlogvar_assign_value(t12, t9, 0, *((unsigned int *)t29), 1);
    goto LAB23;

LAB24:    t24 = *((unsigned int *)t9);
    t25 = *((unsigned int *)t13);
    *((unsigned int *)t9) = (t24 | t25);
    t14 = (t6 + 4);
    t30 = (t10 + 4);
    t26 = *((unsigned int *)t6);
    t27 = (~(t26));
    t28 = *((unsigned int *)t14);
    t33 = (~(t28));
    t34 = *((unsigned int *)t10);
    t35 = (~(t34));
    t36 = *((unsigned int *)t30);
    t37 = (~(t36));
    t16 = (t27 & t33);
    t38 = (t35 & t37);
    t39 = (~(t16));
    t40 = (~(t38));
    t41 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t41 & t39);
    t42 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t42 & t40);
    t43 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t43 & t39);
    t44 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t44 & t40);
    goto LAB26;

LAB27:    xsi_vlogvar_assign_value(t31, t9, 0, *((unsigned int *)t29), 1);
    goto LAB28;

LAB29:    *((unsigned int *)t9) = 1;
    goto LAB32;

LAB34:    t23 = *((unsigned int *)t9);
    t24 = *((unsigned int *)t14);
    *((unsigned int *)t9) = (t23 | t24);
    t25 = *((unsigned int *)t13);
    t26 = *((unsigned int *)t14);
    *((unsigned int *)t13) = (t25 | t26);
    goto LAB33;

LAB35:    t42 = *((unsigned int *)t29);
    t43 = *((unsigned int *)t32);
    *((unsigned int *)t29) = (t42 | t43);
    t45 = (t6 + 4);
    t46 = (t9 + 4);
    t44 = *((unsigned int *)t6);
    t49 = (~(t44));
    t51 = *((unsigned int *)t45);
    t52 = (~(t51));
    t53 = *((unsigned int *)t9);
    t54 = (~(t53));
    t55 = *((unsigned int *)t46);
    t56 = (~(t55));
    t16 = (t49 & t52);
    t38 = (t54 & t56);
    t57 = (~(t16));
    t58 = (~(t38));
    t59 = *((unsigned int *)t32);
    *((unsigned int *)t32) = (t59 & t57);
    t60 = *((unsigned int *)t32);
    *((unsigned int *)t32) = (t60 & t58);
    t61 = *((unsigned int *)t29);
    *((unsigned int *)t29) = (t61 & t57);
    t62 = *((unsigned int *)t29);
    *((unsigned int *)t29) = (t62 & t58);
    goto LAB37;

LAB38:    xsi_vlogvar_assign_value(t47, t29, 0, *((unsigned int *)t63), 1);
    goto LAB39;

LAB40:    t24 = *((unsigned int *)t9);
    t25 = *((unsigned int *)t13);
    *((unsigned int *)t9) = (t24 | t25);
    t14 = (t6 + 4);
    t30 = (t10 + 4);
    t26 = *((unsigned int *)t6);
    t27 = (~(t26));
    t28 = *((unsigned int *)t14);
    t33 = (~(t28));
    t34 = *((unsigned int *)t10);
    t35 = (~(t34));
    t36 = *((unsigned int *)t30);
    t37 = (~(t36));
    t16 = (t27 & t33);
    t38 = (t35 & t37);
    t39 = (~(t16));
    t40 = (~(t38));
    t41 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t41 & t39);
    t42 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t42 & t40);
    t43 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t43 & t39);
    t44 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t44 & t40);
    goto LAB42;

LAB43:    *((unsigned int *)t29) = 1;
    goto LAB46;

LAB48:    t57 = *((unsigned int *)t29);
    t58 = *((unsigned int *)t67);
    *((unsigned int *)t29) = (t57 | t58);
    t59 = *((unsigned int *)t66);
    t60 = *((unsigned int *)t67);
    *((unsigned int *)t66) = (t59 | t60);
    goto LAB47;

LAB49:    t79 = *((unsigned int *)t63);
    t80 = *((unsigned int *)t73);
    *((unsigned int *)t63) = (t79 | t80);
    t81 = (t45 + 4);
    t82 = (t29 + 4);
    t83 = *((unsigned int *)t45);
    t84 = (~(t83));
    t85 = *((unsigned int *)t81);
    t86 = (~(t85));
    t87 = *((unsigned int *)t29);
    t88 = (~(t87));
    t89 = *((unsigned int *)t82);
    t90 = (~(t89));
    t50 = (t84 & t86);
    t91 = (t88 & t90);
    t92 = (~(t50));
    t93 = (~(t91));
    t94 = *((unsigned int *)t73);
    *((unsigned int *)t73) = (t94 & t92);
    t95 = *((unsigned int *)t73);
    *((unsigned int *)t73) = (t95 & t93);
    t96 = *((unsigned int *)t63);
    *((unsigned int *)t63) = (t96 & t92);
    t97 = *((unsigned int *)t63);
    *((unsigned int *)t63) = (t97 & t93);
    goto LAB51;

LAB52:    t110 = *((unsigned int *)t98);
    t111 = *((unsigned int *)t104);
    *((unsigned int *)t98) = (t110 | t111);
    t112 = (t9 + 4);
    t113 = (t63 + 4);
    t114 = *((unsigned int *)t112);
    t115 = (~(t114));
    t116 = *((unsigned int *)t9);
    t117 = (t116 & t115);
    t118 = *((unsigned int *)t113);
    t119 = (~(t118));
    t120 = *((unsigned int *)t63);
    t121 = (t120 & t119);
    t122 = (~(t117));
    t123 = (~(t121));
    t124 = *((unsigned int *)t104);
    *((unsigned int *)t104) = (t124 & t122);
    t125 = *((unsigned int *)t104);
    *((unsigned int *)t104) = (t125 & t123);
    goto LAB54;

LAB55:    xsi_vlogvar_assign_value(t126, t98, 0, *((unsigned int *)t127), 1);
    goto LAB56;

}

static void Initial_65_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    int t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;

LAB0:    t1 = (t0 + 4888U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(65, ng0);

LAB4:    xsi_set_current_line(66, ng0);
    t2 = (t0 + 4696);
    xsi_process_wait(t2, 0LL);
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(66, ng0);
    t3 = ((char*)((ng4)));
    t4 = (t0 + 3176);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 1);
    xsi_set_current_line(66, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 3336);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(66, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 3496);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(67, ng0);
    t2 = (t0 + 4696);
    xsi_process_wait(t2, 0LL);
    *((char **)t1) = &&LAB6;
    goto LAB1;

LAB6:    xsi_set_current_line(67, ng0);
    t3 = (t0 + 4696);
    t4 = (t0 + 2144);
    t5 = xsi_create_subprogram_invocation(t3, 0, t0, t4, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t4, t5);

LAB9:    t6 = (t0 + 4792);
    t7 = *((char **)t6);
    t8 = (t7 + 80U);
    t9 = *((char **)t8);
    t10 = (t9 + 272U);
    t11 = *((char **)t10);
    t12 = (t11 + 0U);
    t13 = *((char **)t12);
    t14 = ((int  (*)(char *, char *))t13)(t0, t7);

LAB11:    if (t14 != 0)
        goto LAB12;

LAB7:    t7 = (t0 + 2144);
    xsi_vlog_subprogram_popinvocation(t7);

LAB8:    t15 = (t0 + 4792);
    t16 = *((char **)t15);
    t15 = (t0 + 2144);
    t17 = (t0 + 4696);
    t18 = 0;
    xsi_delete_subprogram_invocation(t15, t16, t0, t17, t18);
    xsi_set_current_line(68, ng0);
    t2 = (t0 + 4696);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB13;
    goto LAB1;

LAB10:;
LAB12:    t6 = (t0 + 4888U);
    *((char **)t6) = &&LAB9;
    goto LAB1;

LAB13:    xsi_set_current_line(68, ng0);
    t3 = (t0 + 4696);
    t4 = (t0 + 848);
    t5 = xsi_create_subprogram_invocation(t3, 0, t0, t4, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t4, t5);

LAB16:    t6 = (t0 + 4792);
    t7 = *((char **)t6);
    t8 = (t7 + 80U);
    t9 = *((char **)t8);
    t10 = (t9 + 272U);
    t11 = *((char **)t10);
    t12 = (t11 + 0U);
    t13 = *((char **)t12);
    t14 = ((int  (*)(char *, char *))t13)(t0, t7);

LAB18:    if (t14 != 0)
        goto LAB19;

LAB14:    t7 = (t0 + 848);
    xsi_vlog_subprogram_popinvocation(t7);

LAB15:    t15 = (t0 + 4792);
    t16 = *((char **)t15);
    t15 = (t0 + 848);
    t17 = (t0 + 4696);
    t18 = 0;
    xsi_delete_subprogram_invocation(t15, t16, t0, t17, t18);
    xsi_set_current_line(69, ng0);
    t2 = (t0 + 4696);
    xsi_process_wait(t2, 0LL);
    *((char **)t1) = &&LAB20;
    goto LAB1;

LAB17:;
LAB19:    t6 = (t0 + 4888U);
    *((char **)t6) = &&LAB16;
    goto LAB1;

LAB20:    xsi_set_current_line(69, ng0);
    t3 = ((char*)((ng4)));
    t4 = (t0 + 3336);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 1);
    xsi_set_current_line(69, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 3496);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(69, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 3176);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(70, ng0);
    t2 = (t0 + 4696);
    xsi_process_wait(t2, 0LL);
    *((char **)t1) = &&LAB21;
    goto LAB1;

LAB21:    xsi_set_current_line(70, ng0);
    t3 = (t0 + 4696);
    t4 = (t0 + 2144);
    t5 = xsi_create_subprogram_invocation(t3, 0, t0, t4, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t4, t5);

LAB24:    t6 = (t0 + 4792);
    t7 = *((char **)t6);
    t8 = (t7 + 80U);
    t9 = *((char **)t8);
    t10 = (t9 + 272U);
    t11 = *((char **)t10);
    t12 = (t11 + 0U);
    t13 = *((char **)t12);
    t14 = ((int  (*)(char *, char *))t13)(t0, t7);

LAB26:    if (t14 != 0)
        goto LAB27;

LAB22:    t7 = (t0 + 2144);
    xsi_vlog_subprogram_popinvocation(t7);

LAB23:    t15 = (t0 + 4792);
    t16 = *((char **)t15);
    t15 = (t0 + 2144);
    t17 = (t0 + 4696);
    t18 = 0;
    xsi_delete_subprogram_invocation(t15, t16, t0, t17, t18);
    xsi_set_current_line(71, ng0);
    t2 = (t0 + 4696);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB28;
    goto LAB1;

LAB25:;
LAB27:    t6 = (t0 + 4888U);
    *((char **)t6) = &&LAB24;
    goto LAB1;

LAB28:    xsi_set_current_line(71, ng0);
    t3 = (t0 + 4696);
    t4 = (t0 + 848);
    t5 = xsi_create_subprogram_invocation(t3, 0, t0, t4, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t4, t5);

LAB31:    t6 = (t0 + 4792);
    t7 = *((char **)t6);
    t8 = (t7 + 80U);
    t9 = *((char **)t8);
    t10 = (t9 + 272U);
    t11 = *((char **)t10);
    t12 = (t11 + 0U);
    t13 = *((char **)t12);
    t14 = ((int  (*)(char *, char *))t13)(t0, t7);

LAB33:    if (t14 != 0)
        goto LAB34;

LAB29:    t7 = (t0 + 848);
    xsi_vlog_subprogram_popinvocation(t7);

LAB30:    t15 = (t0 + 4792);
    t16 = *((char **)t15);
    t15 = (t0 + 848);
    t17 = (t0 + 4696);
    t18 = 0;
    xsi_delete_subprogram_invocation(t15, t16, t0, t17, t18);
    xsi_set_current_line(72, ng0);
    t2 = (t0 + 4696);
    xsi_process_wait(t2, 0LL);
    *((char **)t1) = &&LAB35;
    goto LAB1;

LAB32:;
LAB34:    t6 = (t0 + 4888U);
    *((char **)t6) = &&LAB31;
    goto LAB1;

LAB35:    xsi_set_current_line(72, ng0);
    t3 = ((char*)((ng4)));
    t4 = (t0 + 3336);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 1);
    xsi_set_current_line(72, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 3496);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(72, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 3176);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(73, ng0);
    t2 = (t0 + 4696);
    xsi_process_wait(t2, 0LL);
    *((char **)t1) = &&LAB36;
    goto LAB1;

LAB36:    xsi_set_current_line(73, ng0);
    t3 = (t0 + 4696);
    t4 = (t0 + 2144);
    t5 = xsi_create_subprogram_invocation(t3, 0, t0, t4, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t4, t5);

LAB39:    t6 = (t0 + 4792);
    t7 = *((char **)t6);
    t8 = (t7 + 80U);
    t9 = *((char **)t8);
    t10 = (t9 + 272U);
    t11 = *((char **)t10);
    t12 = (t11 + 0U);
    t13 = *((char **)t12);
    t14 = ((int  (*)(char *, char *))t13)(t0, t7);

LAB41:    if (t14 != 0)
        goto LAB42;

LAB37:    t7 = (t0 + 2144);
    xsi_vlog_subprogram_popinvocation(t7);

LAB38:    t15 = (t0 + 4792);
    t16 = *((char **)t15);
    t15 = (t0 + 2144);
    t17 = (t0 + 4696);
    t18 = 0;
    xsi_delete_subprogram_invocation(t15, t16, t0, t17, t18);
    xsi_set_current_line(74, ng0);
    t2 = (t0 + 4696);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB43;
    goto LAB1;

LAB40:;
LAB42:    t6 = (t0 + 4888U);
    *((char **)t6) = &&LAB39;
    goto LAB1;

LAB43:    xsi_set_current_line(74, ng0);
    t3 = (t0 + 4696);
    t4 = (t0 + 848);
    t5 = xsi_create_subprogram_invocation(t3, 0, t0, t4, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t4, t5);

LAB46:    t6 = (t0 + 4792);
    t7 = *((char **)t6);
    t8 = (t7 + 80U);
    t9 = *((char **)t8);
    t10 = (t9 + 272U);
    t11 = *((char **)t10);
    t12 = (t11 + 0U);
    t13 = *((char **)t12);
    t14 = ((int  (*)(char *, char *))t13)(t0, t7);

LAB48:    if (t14 != 0)
        goto LAB49;

LAB44:    t7 = (t0 + 848);
    xsi_vlog_subprogram_popinvocation(t7);

LAB45:    t15 = (t0 + 4792);
    t16 = *((char **)t15);
    t15 = (t0 + 848);
    t17 = (t0 + 4696);
    t18 = 0;
    xsi_delete_subprogram_invocation(t15, t16, t0, t17, t18);
    xsi_set_current_line(75, ng0);
    t2 = (t0 + 4696);
    xsi_process_wait(t2, 0LL);
    *((char **)t1) = &&LAB50;
    goto LAB1;

LAB47:;
LAB49:    t6 = (t0 + 4888U);
    *((char **)t6) = &&LAB46;
    goto LAB1;

LAB50:    xsi_set_current_line(75, ng0);
    t3 = ((char*)((ng4)));
    t4 = (t0 + 3336);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 1);
    xsi_set_current_line(75, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 3496);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(75, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 3176);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(76, ng0);
    t2 = (t0 + 4696);
    xsi_process_wait(t2, 0LL);
    *((char **)t1) = &&LAB51;
    goto LAB1;

LAB51:    xsi_set_current_line(76, ng0);
    t3 = (t0 + 4696);
    t4 = (t0 + 2144);
    t5 = xsi_create_subprogram_invocation(t3, 0, t0, t4, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t4, t5);

LAB54:    t6 = (t0 + 4792);
    t7 = *((char **)t6);
    t8 = (t7 + 80U);
    t9 = *((char **)t8);
    t10 = (t9 + 272U);
    t11 = *((char **)t10);
    t12 = (t11 + 0U);
    t13 = *((char **)t12);
    t14 = ((int  (*)(char *, char *))t13)(t0, t7);

LAB56:    if (t14 != 0)
        goto LAB57;

LAB52:    t7 = (t0 + 2144);
    xsi_vlog_subprogram_popinvocation(t7);

LAB53:    t15 = (t0 + 4792);
    t16 = *((char **)t15);
    t15 = (t0 + 2144);
    t17 = (t0 + 4696);
    t18 = 0;
    xsi_delete_subprogram_invocation(t15, t16, t0, t17, t18);
    xsi_set_current_line(77, ng0);
    t2 = (t0 + 4696);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB58;
    goto LAB1;

LAB55:;
LAB57:    t6 = (t0 + 4888U);
    *((char **)t6) = &&LAB54;
    goto LAB1;

LAB58:    xsi_set_current_line(77, ng0);
    t3 = (t0 + 4696);
    t4 = (t0 + 848);
    t5 = xsi_create_subprogram_invocation(t3, 0, t0, t4, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t4, t5);

LAB61:    t6 = (t0 + 4792);
    t7 = *((char **)t6);
    t8 = (t7 + 80U);
    t9 = *((char **)t8);
    t10 = (t9 + 272U);
    t11 = *((char **)t10);
    t12 = (t11 + 0U);
    t13 = *((char **)t12);
    t14 = ((int  (*)(char *, char *))t13)(t0, t7);

LAB63:    if (t14 != 0)
        goto LAB64;

LAB59:    t7 = (t0 + 848);
    xsi_vlog_subprogram_popinvocation(t7);

LAB60:    t15 = (t0 + 4792);
    t16 = *((char **)t15);
    t15 = (t0 + 848);
    t17 = (t0 + 4696);
    t18 = 0;
    xsi_delete_subprogram_invocation(t15, t16, t0, t17, t18);
    xsi_set_current_line(78, ng0);
    t2 = (t0 + 4696);
    xsi_process_wait(t2, 0LL);
    *((char **)t1) = &&LAB65;
    goto LAB1;

LAB62:;
LAB64:    t6 = (t0 + 4888U);
    *((char **)t6) = &&LAB61;
    goto LAB1;

LAB65:    xsi_set_current_line(78, ng0);
    t3 = ((char*)((ng3)));
    t4 = (t0 + 3336);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 1);
    xsi_set_current_line(78, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 3496);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(78, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 3176);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(79, ng0);
    t2 = (t0 + 4696);
    xsi_process_wait(t2, 0LL);
    *((char **)t1) = &&LAB66;
    goto LAB1;

LAB66:    xsi_set_current_line(79, ng0);
    t3 = (t0 + 4696);
    t4 = (t0 + 2144);
    t5 = xsi_create_subprogram_invocation(t3, 0, t0, t4, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t4, t5);

LAB69:    t6 = (t0 + 4792);
    t7 = *((char **)t6);
    t8 = (t7 + 80U);
    t9 = *((char **)t8);
    t10 = (t9 + 272U);
    t11 = *((char **)t10);
    t12 = (t11 + 0U);
    t13 = *((char **)t12);
    t14 = ((int  (*)(char *, char *))t13)(t0, t7);

LAB71:    if (t14 != 0)
        goto LAB72;

LAB67:    t7 = (t0 + 2144);
    xsi_vlog_subprogram_popinvocation(t7);

LAB68:    t15 = (t0 + 4792);
    t16 = *((char **)t15);
    t15 = (t0 + 2144);
    t17 = (t0 + 4696);
    t18 = 0;
    xsi_delete_subprogram_invocation(t15, t16, t0, t17, t18);
    xsi_set_current_line(80, ng0);
    t2 = (t0 + 4696);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB73;
    goto LAB1;

LAB70:;
LAB72:    t6 = (t0 + 4888U);
    *((char **)t6) = &&LAB69;
    goto LAB1;

LAB73:    xsi_set_current_line(80, ng0);
    t3 = (t0 + 4696);
    t4 = (t0 + 848);
    t5 = xsi_create_subprogram_invocation(t3, 0, t0, t4, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t4, t5);

LAB76:    t6 = (t0 + 4792);
    t7 = *((char **)t6);
    t8 = (t7 + 80U);
    t9 = *((char **)t8);
    t10 = (t9 + 272U);
    t11 = *((char **)t10);
    t12 = (t11 + 0U);
    t13 = *((char **)t12);
    t14 = ((int  (*)(char *, char *))t13)(t0, t7);

LAB78:    if (t14 != 0)
        goto LAB79;

LAB74:    t7 = (t0 + 848);
    xsi_vlog_subprogram_popinvocation(t7);

LAB75:    t15 = (t0 + 4792);
    t16 = *((char **)t15);
    t15 = (t0 + 848);
    t17 = (t0 + 4696);
    t18 = 0;
    xsi_delete_subprogram_invocation(t15, t16, t0, t17, t18);
    xsi_set_current_line(81, ng0);
    t2 = (t0 + 4696);
    xsi_process_wait(t2, 0LL);
    *((char **)t1) = &&LAB80;
    goto LAB1;

LAB77:;
LAB79:    t6 = (t0 + 4888U);
    *((char **)t6) = &&LAB76;
    goto LAB1;

LAB80:    xsi_set_current_line(81, ng0);
    t3 = ((char*)((ng3)));
    t4 = (t0 + 3336);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 1);
    xsi_set_current_line(81, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 3496);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(81, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 3176);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(82, ng0);
    t2 = (t0 + 4696);
    xsi_process_wait(t2, 0LL);
    *((char **)t1) = &&LAB81;
    goto LAB1;

LAB81:    xsi_set_current_line(82, ng0);
    t3 = (t0 + 4696);
    t4 = (t0 + 2144);
    t5 = xsi_create_subprogram_invocation(t3, 0, t0, t4, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t4, t5);

LAB84:    t6 = (t0 + 4792);
    t7 = *((char **)t6);
    t8 = (t7 + 80U);
    t9 = *((char **)t8);
    t10 = (t9 + 272U);
    t11 = *((char **)t10);
    t12 = (t11 + 0U);
    t13 = *((char **)t12);
    t14 = ((int  (*)(char *, char *))t13)(t0, t7);

LAB86:    if (t14 != 0)
        goto LAB87;

LAB82:    t7 = (t0 + 2144);
    xsi_vlog_subprogram_popinvocation(t7);

LAB83:    t15 = (t0 + 4792);
    t16 = *((char **)t15);
    t15 = (t0 + 2144);
    t17 = (t0 + 4696);
    t18 = 0;
    xsi_delete_subprogram_invocation(t15, t16, t0, t17, t18);
    xsi_set_current_line(83, ng0);
    t2 = (t0 + 4696);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB88;
    goto LAB1;

LAB85:;
LAB87:    t6 = (t0 + 4888U);
    *((char **)t6) = &&LAB84;
    goto LAB1;

LAB88:    xsi_set_current_line(83, ng0);
    t3 = (t0 + 4696);
    t4 = (t0 + 848);
    t5 = xsi_create_subprogram_invocation(t3, 0, t0, t4, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t4, t5);

LAB91:    t6 = (t0 + 4792);
    t7 = *((char **)t6);
    t8 = (t7 + 80U);
    t9 = *((char **)t8);
    t10 = (t9 + 272U);
    t11 = *((char **)t10);
    t12 = (t11 + 0U);
    t13 = *((char **)t12);
    t14 = ((int  (*)(char *, char *))t13)(t0, t7);

LAB93:    if (t14 != 0)
        goto LAB94;

LAB89:    t7 = (t0 + 848);
    xsi_vlog_subprogram_popinvocation(t7);

LAB90:    t15 = (t0 + 4792);
    t16 = *((char **)t15);
    t15 = (t0 + 848);
    t17 = (t0 + 4696);
    t18 = 0;
    xsi_delete_subprogram_invocation(t15, t16, t0, t17, t18);
    xsi_set_current_line(84, ng0);
    t2 = (t0 + 4696);
    xsi_process_wait(t2, 0LL);
    *((char **)t1) = &&LAB95;
    goto LAB1;

LAB92:;
LAB94:    t6 = (t0 + 4888U);
    *((char **)t6) = &&LAB91;
    goto LAB1;

LAB95:    xsi_set_current_line(84, ng0);
    t3 = ((char*)((ng3)));
    t4 = (t0 + 3336);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 1);
    xsi_set_current_line(84, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 3496);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(84, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 3176);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(85, ng0);
    t2 = (t0 + 4696);
    xsi_process_wait(t2, 0LL);
    *((char **)t1) = &&LAB96;
    goto LAB1;

LAB96:    xsi_set_current_line(85, ng0);
    t3 = (t0 + 4696);
    t4 = (t0 + 2144);
    t5 = xsi_create_subprogram_invocation(t3, 0, t0, t4, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t4, t5);

LAB99:    t6 = (t0 + 4792);
    t7 = *((char **)t6);
    t8 = (t7 + 80U);
    t9 = *((char **)t8);
    t10 = (t9 + 272U);
    t11 = *((char **)t10);
    t12 = (t11 + 0U);
    t13 = *((char **)t12);
    t14 = ((int  (*)(char *, char *))t13)(t0, t7);

LAB101:    if (t14 != 0)
        goto LAB102;

LAB97:    t7 = (t0 + 2144);
    xsi_vlog_subprogram_popinvocation(t7);

LAB98:    t15 = (t0 + 4792);
    t16 = *((char **)t15);
    t15 = (t0 + 2144);
    t17 = (t0 + 4696);
    t18 = 0;
    xsi_delete_subprogram_invocation(t15, t16, t0, t17, t18);
    xsi_set_current_line(86, ng0);
    t2 = (t0 + 4696);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB103;
    goto LAB1;

LAB100:;
LAB102:    t6 = (t0 + 4888U);
    *((char **)t6) = &&LAB99;
    goto LAB1;

LAB103:    xsi_set_current_line(86, ng0);
    t3 = (t0 + 4696);
    t4 = (t0 + 848);
    t5 = xsi_create_subprogram_invocation(t3, 0, t0, t4, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t4, t5);

LAB106:    t6 = (t0 + 4792);
    t7 = *((char **)t6);
    t8 = (t7 + 80U);
    t9 = *((char **)t8);
    t10 = (t9 + 272U);
    t11 = *((char **)t10);
    t12 = (t11 + 0U);
    t13 = *((char **)t12);
    t14 = ((int  (*)(char *, char *))t13)(t0, t7);

LAB108:    if (t14 != 0)
        goto LAB109;

LAB104:    t7 = (t0 + 848);
    xsi_vlog_subprogram_popinvocation(t7);

LAB105:    t15 = (t0 + 4792);
    t16 = *((char **)t15);
    t15 = (t0 + 848);
    t17 = (t0 + 4696);
    t18 = 0;
    xsi_delete_subprogram_invocation(t15, t16, t0, t17, t18);
    xsi_set_current_line(87, ng0);
    t2 = (t0 + 4696);
    xsi_process_wait(t2, 0LL);
    *((char **)t1) = &&LAB110;
    goto LAB1;

LAB107:;
LAB109:    t6 = (t0 + 4888U);
    *((char **)t6) = &&LAB106;
    goto LAB1;

LAB110:    xsi_set_current_line(87, ng0);
    t3 = ((char*)((ng3)));
    t4 = (t0 + 3336);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 1);
    xsi_set_current_line(87, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 3496);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(87, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 3176);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    xsi_set_current_line(88, ng0);
    t2 = (t0 + 4696);
    xsi_process_wait(t2, 0LL);
    *((char **)t1) = &&LAB111;
    goto LAB1;

LAB111:    xsi_set_current_line(88, ng0);
    t3 = (t0 + 4696);
    t4 = (t0 + 2144);
    t5 = xsi_create_subprogram_invocation(t3, 0, t0, t4, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t4, t5);

LAB114:    t6 = (t0 + 4792);
    t7 = *((char **)t6);
    t8 = (t7 + 80U);
    t9 = *((char **)t8);
    t10 = (t9 + 272U);
    t11 = *((char **)t10);
    t12 = (t11 + 0U);
    t13 = *((char **)t12);
    t14 = ((int  (*)(char *, char *))t13)(t0, t7);

LAB116:    if (t14 != 0)
        goto LAB117;

LAB112:    t7 = (t0 + 2144);
    xsi_vlog_subprogram_popinvocation(t7);

LAB113:    t15 = (t0 + 4792);
    t16 = *((char **)t15);
    t15 = (t0 + 2144);
    t17 = (t0 + 4696);
    t18 = 0;
    xsi_delete_subprogram_invocation(t15, t16, t0, t17, t18);
    xsi_set_current_line(89, ng0);
    t2 = (t0 + 4696);
    xsi_process_wait(t2, 5000LL);
    *((char **)t1) = &&LAB118;
    goto LAB1;

LAB115:;
LAB117:    t6 = (t0 + 4888U);
    *((char **)t6) = &&LAB114;
    goto LAB1;

LAB118:    xsi_set_current_line(89, ng0);
    t3 = (t0 + 4696);
    t4 = (t0 + 848);
    t5 = xsi_create_subprogram_invocation(t3, 0, t0, t4, 0, 0);
    xsi_vlog_subprogram_pushinvocation(t4, t5);

LAB121:    t6 = (t0 + 4792);
    t7 = *((char **)t6);
    t8 = (t7 + 80U);
    t9 = *((char **)t8);
    t10 = (t9 + 272U);
    t11 = *((char **)t10);
    t12 = (t11 + 0U);
    t13 = *((char **)t12);
    t14 = ((int  (*)(char *, char *))t13)(t0, t7);

LAB123:    if (t14 != 0)
        goto LAB124;

LAB119:    t7 = (t0 + 848);
    xsi_vlog_subprogram_popinvocation(t7);

LAB120:    t15 = (t0 + 4792);
    t16 = *((char **)t15);
    t15 = (t0 + 848);
    t17 = (t0 + 4696);
    t18 = 0;
    xsi_delete_subprogram_invocation(t15, t16, t0, t17, t18);
    xsi_set_current_line(90, ng0);
    t2 = (t0 + 4696);
    xsi_process_wait(t2, 0LL);
    *((char **)t1) = &&LAB125;
    goto LAB1;

LAB122:;
LAB124:    t6 = (t0 + 4888U);
    *((char **)t6) = &&LAB121;
    goto LAB1;

LAB125:    xsi_set_current_line(90, ng0);
    xsi_vlogfile_write(1, 0, 0, ng13, 1, t0);
    xsi_set_current_line(91, ng0);
    xsi_vlog_finish(1);
    goto LAB1;

}


extern void work_m_09324587413088437173_2086858183_init()
{
	static char *pe[] = {(void *)Initial_65_0};
	static char *se[] = {(void *)sp_test_current_config,(void *)sp_display_task,(void *)sp_update_task,(void *)sp_update_golden};
	xsi_register_didat("work_m_09324587413088437173_2086858183", "isim/test_mux_isim_beh.exe.sim/work/m_09324587413088437173_2086858183.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
